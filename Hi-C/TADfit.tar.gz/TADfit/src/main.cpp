#include "diffTADs.h"

int main()
{

}
