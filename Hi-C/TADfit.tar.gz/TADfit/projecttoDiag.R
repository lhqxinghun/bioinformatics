projecttoDiag <- function(output,repeatnum,resolution,start,chr,method)
{
  options(scipen = 15)
  #初始化
  tadRegion=matrix(0,length(unique(output[["TADs"]][,"right"])),3)
  colnames(tadRegion) <- c("left","right","Beta_Diag")

  #提取TAD区域
  R2=output[["R2"]]
  TADs=output[["TADs"]]
  idx=0
  for (i in unique(TADs[,"right"])) {
    idx=idx+1
    temp=TADs[TADs[,"right"]==i,]
    if(is.null(nrow(temp))){
      temp=t(as.matrix(temp))
    }
    tadRegion[idx,"left"]=temp[nrow(temp),"left"]
    tadRegion[idx,"right"]=temp[nrow(temp),"right"]
  }

  #将beta横向投影到对角线上

  for (idx in 1:nrow(tadRegion)) {
    left=tadRegion[idx,"left"]
    right=tadRegion[idx,"right"]
    temp=TADs[TADs[,"left"]<=left&TADs[,"right"]>=right,]

    if(is.null(nrow(temp))){
      temp=t(as.matrix(temp))
    }
    tadRegion[idx,"Beta_Diag"]=sum(rowMeans(temp[,5:(5+repeatnum-1)]))
  }

  #将beta纵向投影到对角线上

  for (idx in 1:nrow(tadRegion)) {
    left=tadRegion[idx,"left"]
    right=tadRegion[idx,"right"]
    temp=TADs[TADs[,"top"]<=left&TADs[,"bottom"]>=right,]

    if(is.null(nrow(temp))){
      temp=t(as.matrix(temp))
    }
    tadRegion[idx,"Beta_Diag"]=tadRegion[idx,"Beta_Diag"]+sum(rowMeans(temp[,5:(5+repeatnum-1)]))
  }

  #数组坐标转换成染色体坐标,以及给文件第一列加上染色体编号
  tadRegion[,"left"]=tadRegion[,"left"]*resolution+start
  tadRegion[,"right"]=(tadRegion[,"right"]+1)*resolution-1+start
  tadRegion=cbind("chr"=chr,tadRegion)
  write.table(tadRegion,paste0(method,"_tad_Beta.bedGraph"),append = TRUE, row.names=FALSE, col.names=FALSE, sep="\t",quote =FALSE)
  
}



