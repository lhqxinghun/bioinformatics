#TADs prediction for single context
file.remove(c("/home/biology/Hic/hicda_liuerhu/DiffTADs/out/p.out","/home/biology/Hic/hicda_liuerhu/DiffTADs/out/y.out"))

rm(list=ls())
setwd("/home/biology/Hic/hicda_liuerhu/DiffTADs")
source("loadmat.R")
source("submatrix.R")
source("TADsda.R")
source("projecttoDiag.R")

dirin <- "/media/disk2/hic-TADrecognition/GM12878/chr1/25K/ICE-CPM"
CPMnormatlist <- loadmat(dirin1=dirin, dirin2=NULL)

start=160000000
end=162000000
resolution=25000
repeatnum=5
iteration=10


#chr1 max 250000000

CPMnormatlist <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr1",start=start,end=end, resolution=resolution)

parFTRLreg=list(repeatnum=repeatnum, iteration=iteration, lambda=0.1, alpha=c(0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlist, matlistcon2=NULL, namecon1="GM12878", parFTRLreg=parFTRLreg)

projecttoDiag(output,repeatnum,resolution,start,"chr1",method="tradition")



#TADs prediction for single context
file.remove(c("/home/biology/Hic/hicda_liuerhu/DiffTADs/out/p.out","/home/biology/Hic/hicda_liuerhu/DiffTADs/out/y.out"))

rm(list=ls())
setwd("/home/biology/Hic/hicda_liuerhu/DiffTADs")
source("loadmat.R")
source("submatrix.R")
source("TADsda.R")
source("projecttoDiag.R")

dirin <- "/media/disk2/hic-TADrecognition/GM12878/chr1/5K-10M/ICE-CPM"
CPMnormatlist <- loadmat(dirin1=dirin, dirin2=NULL)

start=0
end=1000000
resolution=5000
repeatnum=5
iteration=10


#chr1 max 250000000

CPMnormatlist <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr1",start=start,end=end, resolution=resolution)

parFTRLreg=list(repeatnum=repeatnum, iteration=iteration, lambda=0.1, alpha=c(0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlist, matlistcon2=NULL, namecon1="GM12878", parFTRLreg=parFTRLreg)

projecttoDiag(output,repeatnum,resolution,start,"chr1",method="tradition")




#######################################################################
#Differetial analysis between two contexts

rm(list=ls())
setwd("/home/biology/Hic/hicda_liuerhu/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")


dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr14/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr14/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
repnum = 2
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr14",start=30000000,end=33000000, resolution=50000)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr14",start=30000000,end=33000000, resolution=50000)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

options(scipen = 100)
write.table(round(output$TADs, digits=6), paste0("./out/TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)
#######################################################################
#Select
pvalue <- output$TADs[,"p-value"]
qvalue <- output$TADs[,"q-value"]
selbyp <- sum(pvalue[!is.na(pvalue)] < 0.05, na.rm=TRUE)
selbyq <- sum(qvalue[!is.na(qvalue)] < 0.05, na.rm=TRUE)





#######################################################################
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 105000000
end <- 115000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr1/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr1/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr1",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr1",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS IMR90/chr1/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS IMR90/chr1/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr1/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr1/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr1/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr1/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr1",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 105000000
end <- 115000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr1/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr1/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr1",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr1",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr1/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr1/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr1/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr1/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr1/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr1/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr1",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)


##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 175000000
end <- 185000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr1/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr1/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr1",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr1",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS IMR90/chr1/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS IMR90/chr1/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr1/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr1/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr1/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr1/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr1",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 175000000
end <- 185000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr1/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr1/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr1",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr1",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr1/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr1/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr1/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr1/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr1/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr1/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr1",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 30000000
end <- 40000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr2/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS IMR90/chr2/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS IMR90/chr2/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr2/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr2/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr2/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr2",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 40000000
end <- 50000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr2/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS IMR90/chr2/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS IMR90/chr2/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr2/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr2/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr2/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr2",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 235000000
end <- 243199373
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr2/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS IMR90/chr2/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS IMR90/chr2/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr2/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr2/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr2/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr2",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 30000000
end <- 40000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr2/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr2/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr2/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr2/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr2/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr2/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr2",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 40000000
end <- 50000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr2/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr2/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr2/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr2/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr2/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr2/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr2",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 235000000
end <- 243199373
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr2/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr2",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr2/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr2/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr2/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr2/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr2/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr2/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr2",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 0
end <- 10000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS K562/GM12878/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS K562/K562/chr8/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS K562/chr8/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS K562/chr8/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS K562/GM12878/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS K562/K562/chr8/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS K562/chr8/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS K562/chr8/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr8",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 0
end <- 10000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr8/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr8/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr8/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr8/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr8/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr8/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr8",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 15000000
end <- 25000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr8/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS IMR90/chr8/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS IMR90/chr8/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr8/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr8/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr8/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr8",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 15000000
end <- 25000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr8/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr8/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr8/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr8/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr8/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr8/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr8",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 135000000
end <- 145000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr8/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS IMR90/chr8/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS IMR90/chr8/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr8/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr8/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr8/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr8",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 135000000
end <- 145000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr8/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr8",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr8/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr8/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr8/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr8/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr8/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr8/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr8",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 80000000
end <- 90000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr14/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr14/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr14",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr14",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS IMR90/chr14/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS IMR90/chr14/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr14/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr14/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr14/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr14/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr14",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 80000000
end <- 90000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr14/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr14/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr14",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr14",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr14/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr14/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr14/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr14/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr14/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr14/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr14",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 90000000
end <- 100000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr14/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr14/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr14",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr14",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS IMR90/chr14/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS IMR90/chr14/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr14/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr14/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr14/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr14/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr14",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 90000000
end <- 100000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr14/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr14/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr14",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr14",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr14/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr14/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr14/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr14/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr14/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr14/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr14",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 60000000
end <- 70000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr18/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr18/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr18",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr18",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="GM12878", namecon2="IMR90", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/GM12878 VS IMR90/chr18/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/GM12878 VS IMR90/chr18/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/GM12878 VS IMR90/GM12878/chr18/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/GM12878 VS IMR90/IMR90/chr18/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr18/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/GM12878 VS IMR90/chr18/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr18",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
##################
rm(list=ls())
setwd("/home/biology/Hic/hicda/DiffTADs")
source("loadmat.R")
source("sparse2matrix.R")
source("normbyCPM.R")
source("submatrix.R")
source("TADsda.R")

repnum <- 4
start <- 60000000
end <- 70000000
resolution <- 50000
options(scipen=999)
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr18/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr18/50K/multiHiCcompare-CPM"
CPMnormatlist <- loadmat(dirin1=dirin1, dirin2=dirin2)

library("gdata")
CPMnormatlist$listcon1 <- first(CPMnormatlist$listcon1, repnum)
CPMnormatlist$listcon2 <- first(CPMnormatlist$listcon2, repnum)

CPMnormatlistcon1 <- lapply(CPMnormatlist$listcon1, submatrix, species="hg19", chr="chr18",start=start,end=end, resolution=resolution)
CPMnormatlistcon2 <- lapply(CPMnormatlist$listcon2, submatrix, species="hg19", chr="chr18",start=start,end=end, resolution=resolution)
rm(CPMnormatlist)

parFTRLreg=list(repeatnum=5, iteration=2, lambda=1, alpha=c(0.005,0.010), beta=c(1), l1=c(1), l2=c(1))
output <- TADsda(matlistcon1=CPMnormatlistcon1, matlistcon2=CPMnormatlistcon2, namecon1="IMR90", namecon2="K562", parFTRLreg=parFTRLreg)
rm(CPMnormatlistcon1, CPMnormatlistcon2)

write.table(round(output$TADs, digits=6), paste0("./out/IMR90 VS K562/chr18/50K/",start,"-",end,"_TADs.out"), sep="\t", col.names=TRUE, row.names=FALSE)
write.table(round(output$R2, digits=6), paste0("./out/IMR90 VS K562/chr18/50K/",start,"-",end,"_R2.out"), sep="\t", col.names=FALSE, row.names=TRUE)


setwd("/home/biology/Hic/hicda/DiffTADs/figures/heatmap")
source("heatmapdis.R")
source("../../submatrix.R")

crisel <- "p-value"
filename <- paste0(start, "-", end, "_by_",crisel,".TIFF")
dirin1 <- "/media/disk2/hicdata/IMR90 VS K562/IMR90/chr18/50K/multiHiCcompare-CPM"
dirin2 <- "/media/disk2/hicdata/IMR90 VS K562/K562/chr18/50K/multiHiCcompare-CPM"
fileTADs <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr18/50K/",start,"-",end,"_TADs.out")
fileout <- paste0("/home/biology/Hic/hicda/DiffTADs/out/IMR90 VS K562/chr18/50K/",filename)
heatmapdis(dirin1, dirin2, repnum=repnum, species="hg19", chr="chr18",start=start,end=end, resolution=resolution, fileTADs=fileTADs, crisel=crisel, fileout=fileout)
