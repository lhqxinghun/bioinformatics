normbyCPM <- function(mat, bmodified=TRUE)
{
  mat[is.na(mat)] <- 0
  if(bmodified == TRUE)
  {
    libs <- sum(mat[upper.tri(mat)], diag = TRUE)  #实际上没有包含对角线,结果影响不大
    mat <- mat/libs*10^7
  }
  else
  {
    libs <- sum(mat[upper.tri(mat)], diag = TRUE)
    mat <- (mat+0.5)/(libs+1)*10^6
  }
  return(mat)
}
